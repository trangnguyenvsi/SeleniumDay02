package day3.selenium;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

public class NewTourSelectFlight {
	Login LogObj;
	FlightFinder FliFinder;
	SelectFlight SelFlight;
	
@Test
public void NewTourSelectFlightSuccess() throws Exception {
	LogObj = new Login("webdriver.chrome.driver","D:/Automation_SurveySite/BrowserDriver/chromedriver_win32/chromedriver.exe");
	Assert.assertEquals("Find a Flight: Mercury Tours:",LogObj.SetUserLogin("tutorial", "tutorial"));
	LogObj.driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	FliFinder = new FlightFinder();
	FliFinder.findFlights(LogObj.driver);
	FliFinder.setValueFlightFinderPage(0, 2, 2, 2, 2, 1, 2, 3, 3, 5);
//	System.out.println(FliFinder);
	FliFinder.clickContinueBtn();
	Assert.assertEquals(LogObj.driver.getCurrentUrl(), "http://newtours.demoaut.com/mercuryreservation2.php");

	SelFlight = new SelectFlight(LogObj.driver);	
	SelFlight.setValueSelectFlight(2, 3);
	String title = SelFlight.clickBtn(LogObj.driver);
	Assert.assertEquals(title, "http://newtours.demoaut.com/mercurypurchase.php");
	String t1 = LogObj.driver.findElement(By.name("outFlightName")).getAttribute("value");
	String t2 = LogObj.driver.findElement(By.name("outFlightNumber")).getAttribute("value");
	Assert.assertTrue(LogObj.driver.getPageSource().contains(t1+" "+t2));
	
	int t3= Integer.parseInt(LogObj.driver.findElement(By.name("outFlightPrice")).getAttribute("value"));
	int t4= Integer.parseInt(LogObj.driver.findElement(By.name("inFlightPrice")).getAttribute("value"));
	int t5= Integer.parseInt(LogObj.driver.findElement(By.name("passCount")).getAttribute("value"));
	int t6= Integer.parseInt(LogObj.driver.findElement(By.name("taxes")).getAttribute("value"));
	int totalPrice = (t3+t4)*t5+t6;
	Assert.assertTrue(LogObj.driver.getPageSource().contains("$"+totalPrice));
	for(int i = 0; i<t5; i++)
	{
		WebElement first = LogObj.driver.findElement(By.name("passFirst"+i));
		Assert.assertTrue(first.getSize()!=null);
		WebElement last = LogObj.driver.findElement(By.name("passLast"+i));
		Assert.assertTrue(last.getSize()!=null);
	}
	
	
}
}
