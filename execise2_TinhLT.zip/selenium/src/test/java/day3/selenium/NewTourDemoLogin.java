package day3.selenium;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class NewTourDemoLogin {

	Login LogObj;
//	@BeforeTest
//	public void setupNewTourDemoLogin()
//	{
//		LogObj = new Login("webdriver.chrome.driver","D:/Automation_SurveySite/BrowserDriver/chromedriver_win32/chromedriver.exe");
//		
//	}
	
	@Test
	public void LoginSuccess() throws Exception 
	{
		LogObj = new Login("webdriver.chrome.driver","D:/Automation_SurveySite/BrowserDriver/chromedriver_win32/chromedriver.exe");
		String title = "";
		title = LogObj.SetUserLogin("tutorial", "tutorial");
		Assert.assertEquals("Find a Flight: Mercury Tours:",title);
		LogObj.tearDown();
			
	}
	@Test
	public void LoginFail() throws Exception
	{
		LogObj = new Login("webdriver.chrome.driver","D:/Automation_SurveySite/BrowserDriver/chromedriver_win32/chromedriver.exe");
		String title1 = "";
		title1 = LogObj.SetUserLogin("tutorial", "tutorial1");
		Assert.assertEquals("Sign-on: Mercury Tours",title1);
		LogObj.tearDown();
	}
//	@AfterTest
//	public void QuitBrowser() throws Exception
//	{
//		LogObj.tearDown();		
//	}
}
