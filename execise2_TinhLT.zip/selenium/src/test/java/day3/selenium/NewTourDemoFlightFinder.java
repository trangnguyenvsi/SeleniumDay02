package day3.selenium;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class NewTourDemoFlightFinder {
Login LogObj;
FlightFinder FliFinder;
//@BeforeTest
//public void setUp()
//{
//	LogObj = new Login("webdriver.chrome.driver","D:/Automation_SurveySite/BrowserDriver/chromedriver_win32/chromedriver.exe");
//	Assert.assertEquals("Find a Flight: Mercury Tours:",LogObj.SetUserLogin("tutorial", "tutorial"));
//	LogObj.driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//	FliFinder = new FlightFinder();
//	FliFinder.findFlights(LogObj.driver);
//	
//}
@Test
public void FlightFinderSuccess() throws Exception {
	
	LogObj = new Login("webdriver.chrome.driver","D:/Automation_SurveySite/BrowserDriver/chromedriver_win32/chromedriver.exe");
	Assert.assertEquals("Find a Flight: Mercury Tours:",LogObj.SetUserLogin("tutorial", "tutorial"));
	LogObj.driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	FliFinder = new FlightFinder();
	FliFinder.findFlights(LogObj.driver);
	FliFinder.setValueFlightFinderPage(0, 2, 2, 2, 2, 1, 2, 3, 3, 5);
//	System.out.println(FliFinder);
	FliFinder.clickContinueBtn();
	Assert.assertEquals(LogObj.driver.getCurrentUrl(), "http://newtours.demoaut.com/mercuryreservation2.php");
//	Assert.assertTrue(LogObj.driver.getPageSource().contains(FliFinder.fromDay.getFirstSelectedOption().getAttribute("value").toString()+"/"+FliFinder.fromMonth.getFirstSelectedOption().getAttribute("value").toString()+"/2016"));
//	System.out.println("cu chuoi: "+FliFinder.fromDay.getFirstSelectedOption().getAttribute("value").toString()+ "  vo van ");
	Assert.assertTrue(LogObj.driver.getPageSource().contains(FliFinder.fromDay.getFirstSelectedOption().getText()+"/"+FliFinder.fromMonth.getFirstSelectedOption().getText()+"/2016"));
//	System.out.println("1 cu chuoi: "+FliFinder.fromDay.getFirstSelectedOption().getText()+ "  1vo van ");
	LogObj.tearDown();
}
@Test
public void FlightFinderFail() throws Exception {
	LogObj = new Login("webdriver.chrome.driver","D:/Automation_SurveySite/BrowserDriver/chromedriver_win32/chromedriver.exe");
	Assert.assertEquals("Find a Flight: Mercury Tours:",LogObj.SetUserLogin("tutorial", "tutorial"));
	LogObj.driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	FliFinder = new FlightFinder();
	FliFinder.findFlights(LogObj.driver);
	FliFinder.setValueFlightFinderPage(0, 2, 2, 2, 2, 1, 5, 2, 1, 2);
	System.out.println(FliFinder);
	FliFinder.clickContinueBtn();
	Assert.assertTrue(LogObj.driver.getPageSource().contains("Please select FromDay < ToDay"));
	LogObj.tearDown();
	
}
//@AfterTest
//public void closeBrowser() throws Exception
//{
//	LogObj.tearDown();
//}
}
