package day3.selenium;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class BookaFlight {
	public static WebElement[] firstName;
	public static WebElement[] LasttName;
	public static Select[] Meal;
	public static Select creditCard;
	public static WebElement creditnumber;
	
	
}
