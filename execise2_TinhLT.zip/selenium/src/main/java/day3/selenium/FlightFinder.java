package day3.selenium;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

public class FlightFinder {
	public static List<WebElement> tripType;
	public static Select passCount;
	public static Select fromPort;
	public static Select fromMonth;
	public static Select fromDay;
	public static Select toPort;
	public static Select toMonth;
	public static Select toDay;
	public static List<WebElement> servClass;
	public static Select airline;
	public static WebElement btnfindFlights;
	
	
	public void findFlights(WebDriver driver)
	{
		this.tripType = driver.findElements(By.name("tripType"));
		this.passCount = new Select(driver.findElement(By.name("passCount")));
		this.fromPort =  new Select(driver.findElement(By.name("fromPort")));
		this.toPort =  new Select(driver.findElement(By.name("toPort")));		
		this.airline =  new Select(driver.findElement(By.name("airline")));
		this.servClass = driver.findElements(By.name("servClass"));
		
		this.fromMonth = new Select(driver.findElement(By.name("fromMonth")));
		this.fromDay = new Select(driver.findElement(By.name("fromDay")));
		this.toMonth = new Select(driver.findElement(By.name("toMonth")));
		this.toDay = new Select(driver.findElement(By.name("toDay")));
		this.btnfindFlights = driver.findElement(By.name("findFlights"));
				
		
	}
	public void setValueFlightFinderPage(int temp1, int temp2, int temp3, int temp4, int temp5, int temp6, int temp7, int temp8, int temp9, int temp10 ) throws Exception 
	{
		
		tripType.get(temp1).click();
		passCount.selectByIndex(temp2);
		fromPort.selectByIndex(temp3);
		toPort.selectByIndex(temp4);
		airline.selectByIndex(temp5);
		servClass.get(temp6).click();
		fromMonth.selectByIndex(temp7);
		fromDay.selectByIndex(temp8);
		toMonth.selectByIndex(temp9);
		toDay.selectByIndex(temp10);
		
		
	}
	public void clickContinueBtn()
	{
		btnfindFlights.click();
	}
	
	
}
