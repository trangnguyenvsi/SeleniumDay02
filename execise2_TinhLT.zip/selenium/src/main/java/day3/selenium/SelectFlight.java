package day3.selenium;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class SelectFlight {

	public static List<WebElement> outFlight;
	public static List<WebElement> inFlight;
	public static WebElement btnreserveFlights;
	public SelectFlight(WebDriver driver)	
	{
		this.outFlight = driver.findElements(By.name("outFlight"));
		this.inFlight = driver.findElements(By.name("inFlight"));
		this.btnreserveFlights = driver.findElement(By.name("reserveFlights"));
	}
	public void setValueSelectFlight(int outFli, int inFli)
	{
		outFlight.get(outFli).click();
		inFlight.get(inFli).click();
		
	}
	public String clickBtn(WebDriver driver) {
		
		btnreserveFlights.click();
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		return driver.getCurrentUrl();
	}
}
