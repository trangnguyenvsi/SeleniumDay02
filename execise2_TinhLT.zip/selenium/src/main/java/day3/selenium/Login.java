package day3.selenium;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class Login {
	public static WebElement user;
	public static WebElement pass;
	public static WebElement btnLogin;	
	public static WebDriver driver;
	String browserType;
	String browPath;

public Login (String browserType, String browPath) {
	
	if(browserType.equals("webdriver.chrome.driver"))
	{
		System.setProperty(browserType,browPath);
		this.driver = new ChromeDriver();		
	}
	else if(browserType.equals("webdriver.ie.driver"))
	{
		System.setProperty(browserType,browPath);
		this.driver = new InternetExplorerDriver();		
	}
	else
	{
		this.driver = new FirefoxDriver();
		
	}	
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	driver.get("http://newtours.demoaut.com");	
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	
	this.user = driver.findElement(By.name("userName"));
	this.pass = driver.findElement(By.name("password"));
	this.btnLogin = driver.findElement(By.name("login"));
	
}

public String SetUserLogin(String userIn, String passIn) {
	user.sendKeys(userIn);
	pass.sendKeys(passIn);
	btnLogin.click();
//	Thread.sleep(3000);
	return (driver.getTitle());
}
public void tearDown() throws Exception {
	driver.quit();
	
}
}
